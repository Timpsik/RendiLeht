<h1><?php echo lang("PankÕnnestus");?></h1> 
<p><?php echo lang("PankÕnnestusTekst");?></p>

<a  href="<?php echo base_url(); ?>"><?php echo lang("Avalehele");?></a>