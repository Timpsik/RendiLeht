<h1><?php echo lang("PankEbaõnnestus");?></h1> 
<p><?php echo lang("PankEbaõnnestusTekst");?></p>

<a  href="<?php echo base_url(); ?>"><?php echo lang("Avalehele");?></a>