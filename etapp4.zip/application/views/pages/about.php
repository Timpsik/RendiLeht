<div class="row">
	<div class="col-md">
		<h1 class="text-center"><?php echo lang("Korduma_kippuvad_küsimused");?></h1>
	</div>
</div>