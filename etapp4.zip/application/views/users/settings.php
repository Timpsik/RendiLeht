  <div class="py-5">
    <div class="container">
      <div class="row">
        </div>
      </div>
    </div>
  </div>
  <div class="py-5">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="row">
            <div class="col-md-6">
              <h5 class="">Nimi:</h5>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6 my-2" style="transition: all 0.25s;">
              <div class="row">
                <div class="col-md-12">
                  <input type="text" class="form-control"> </div>
              </div>
            </div>
          </div>
            <div class="col-md-6">
              <h5 class="my-2">E-mail:</h5>
            </div>
          </div>
            <div class="col-md-6">
              <input type="text" class="form-control my-2"> </div>
          </div>
          <div class="row">
            <div class="col-md-6">
              <h5 class="my-2">Telefoni number:</h5>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6">
              <input type="text" class="form-control"> </div>
          </div>
          <div class="row">
            <div class="col-md-6 offset-md-4"> </div>
          </div>
          <div class="row">
            <div class="col-md-6">
              <h5 class="my-2">Pangakonto number:</h5>
            </div>
            <div class="col-md-6 ">
              <div class="col-md-12"> </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6">
              <input type="text" class="form-control my-2">
              <a class="btn btn-primary my-2 w-25" href="#">Muuda</a>
            </div>
          </div>
          <div class="row">
            <div class="col-md-8 offset-md-4"> </div>
          </div>
        </div>
 
  
