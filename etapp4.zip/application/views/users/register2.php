	<div class="row">
		<div class="col-md-4 col-md-offset-4">
			<h1 class="text-center"><?php echo lang("Registreeru");?></h1>
			<br>
		</div>
			<div class="btn-group btn-group-justified">
				<a href="<?php echo site_url('/registeremail/'); ?>" class="btn btn-default">Emailiga</a>
				<a href="#" class="btn btn-default">ID-kaardiga</a>
				<a href="#" class="btn btn-default">Facebookiga</a>
			</div>