 <h1><?php echo lang("Stats_riik");?></h1> 
    <div id="chart_loc"></div> 
	 <h1><?php echo lang("Stats_brauser");?></h1> 
    <div id="chart_browser"></div> 
	 <h1><?php echo lang("Stats_OS");?></h1> 
    <div id="chart_OS"></div> 